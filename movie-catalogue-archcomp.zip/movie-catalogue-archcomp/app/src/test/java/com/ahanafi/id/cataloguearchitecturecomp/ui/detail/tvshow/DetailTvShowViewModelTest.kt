package com.ahanafi.id.cataloguearchitecturecomp.ui.detail.tvshow

import com.ahanafi.id.cataloguearchitecturecomp.utils.TvShowDummy
import org.junit.Test

import org.junit.Assert.*
import org.junit.Before

class DetailTvShowViewModelTest {
    private lateinit var viewModel: DetailTvShowViewModel
    private val dummyTvShow = TvShowDummy.generateTvShow()[0]
    private val movieId = dummyTvShow.id.toString()

    @Before
    fun setUp() {
        viewModel = DetailTvShowViewModel()
        viewModel.setSelectedTvShow(movieId)
    }

    @Test
    fun setSelectedMovie() {
        viewModel.setSelectedTvShow(dummyTvShow.id.toString())
        val tvShow = viewModel.getTvShow()
        assertNotNull(tvShow)
        assertEquals(tvShow.id, dummyTvShow.id)
        assertEquals(tvShow.title, dummyTvShow.title)
        assertEquals(tvShow.releaseDate, dummyTvShow.releaseDate)
        assertEquals(tvShow.language, dummyTvShow.language)
        assertEquals(tvShow.overview, dummyTvShow.overview)
        assertEquals(tvShow.voteCount, dummyTvShow.voteCount)
        assertEquals(tvShow.posterPath, dummyTvShow.posterPath)
        assertEquals(tvShow.backdropPath, dummyTvShow.backdropPath)
    }

    @Test
    fun getMovie() {
        val movie = viewModel.getTvShow()
        assertNotNull(movie)
    }
}