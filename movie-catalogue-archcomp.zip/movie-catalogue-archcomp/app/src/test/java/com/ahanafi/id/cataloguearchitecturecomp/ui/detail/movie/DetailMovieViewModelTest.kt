package com.ahanafi.id.cataloguearchitecturecomp.ui.detail.movie

import com.ahanafi.id.cataloguearchitecturecomp.utils.MovieDummy
import org.junit.Before
import org.junit.Test

import org.junit.Assert.*

class DetailMovieViewModelTest {

    private lateinit var viewModel: DetailMovieViewModel
    private val dummyMovie = MovieDummy.generateMovies()[0]
    private val movieId = dummyMovie.id.toString()

    @Before
    fun setUp() {
        viewModel = DetailMovieViewModel()
        viewModel.setSelectedMovie(movieId)
    }

    @Test
    fun setSelectedMovie() {
        viewModel.setSelectedMovie(dummyMovie.id.toString())
        val movie = viewModel.getMovie()
        assertNotNull(movie)
        assertEquals(movie.id, dummyMovie.id)
        assertEquals(movie.title, dummyMovie.title)
        assertEquals(movie.releaseDate, dummyMovie.releaseDate)
        assertEquals(movie.language, dummyMovie.language)
        assertEquals(movie.overview, dummyMovie.overview)
        assertEquals(movie.voteCount, dummyMovie.voteCount)
        assertEquals(movie.posterPath, dummyMovie.posterPath)
        assertEquals(movie.backdropPath, dummyMovie.backdropPath)
    }

    @Test
    fun getMovie() {
        val movie = viewModel.getMovie()
        assertNotNull(movie)
    }
}