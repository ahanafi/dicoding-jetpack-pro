package com.ahanafi.id.cataloguearchitecturecomp.ui.tvshow

import androidx.lifecycle.ViewModel
import com.ahanafi.id.cataloguearchitecturecomp.data.TvShow
import com.ahanafi.id.cataloguearchitecturecomp.utils.TvShowDummy

class TvShowViewModel : ViewModel() {
    fun getTvShows() : List<TvShow> = TvShowDummy.generateTvShow()
}