package com.ahanafi.id.cataloguearchitecturecomp.ui.detail.tvshow

import androidx.lifecycle.ViewModel
import com.ahanafi.id.cataloguearchitecturecomp.data.TvShow
import com.ahanafi.id.cataloguearchitecturecomp.utils.TvShowDummy

class DetailTvShowViewModel : ViewModel() {
    private lateinit var tvShowId : String

    fun setSelectedTvShow(tvShowId : String) {
        this.tvShowId = tvShowId
    }

    fun getTvShow() : TvShow {
        lateinit var tvShow : TvShow
        val tvShows = TvShowDummy.generateTvShow()
        for (tvShowData in tvShows) {
            if (tvShowData.id == tvShowId.toInt()) {
                tvShow = tvShowData
            }
        }
        return tvShow
    }
}