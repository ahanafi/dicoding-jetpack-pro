package com.ahanafi.id.cataloguearchitecturecomp.ui.movie

import androidx.lifecycle.ViewModel
import com.ahanafi.id.cataloguearchitecturecomp.data.Movie
import com.ahanafi.id.cataloguearchitecturecomp.utils.MovieDummy

class MovieViewModel : ViewModel() {
    fun getMovies() : List<Movie> = MovieDummy.generateMovies()
}